#!/bin/bash
python3 /opt/bbremoto/"BB Remoto"