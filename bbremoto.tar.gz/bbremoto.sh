#!/bin/bash
home=($(eval echo ~$USER))
python3 $home/.local/share/bbremoto/"BB Remoto"